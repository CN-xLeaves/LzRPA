
#include "Bword.inc"



int main()
{
  //TESTS
  //
  /*
  bstring       p=NULL,q=NULL;
  bstringcatl   (&p,"Hello ");
  bstringcatl   (&q,"World ");
  bstringcat    (&p,q);
  bstringcatl   (&p," ok");
  bstringsetlen (&p,15);
  bstringmid    (&p,p,-9,11);
  bstringmidpl  (&p,"X",2);
  printf        ("%s\n",p);
  printf        ("%i\n",bstringlen(p));
  bstringfree   (&p);
  */
  char s[]="\
  Hello Brave New World!!\\\
  ";
  int  i=0,j;
  bword w;
  for (j=1;j<8;j++)
  {
    wword(&w,s,&i);
    ShowWord(&w,s);
    if (s[i]==0) break;
  }
  printf("\n%i",j);
  printf("\n%i",w.ascw);
  printf("\n%i",w.ascn);
}
