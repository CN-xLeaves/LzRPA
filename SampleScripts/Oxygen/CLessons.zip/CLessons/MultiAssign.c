#include <stdlib.h>
#include <stdio.h>
#include <string.h>



typedef struct 
{
  int a,b,c;
} cfoo;



int main()
{
  cfoo foo;
  int i[3]={10,20,30};
  memcpy(&foo,&i[0],sizeof(cfoo));
  printf ("%i\n",sizeof(cfoo));
  printf ("%i\n",foo.b);
}


