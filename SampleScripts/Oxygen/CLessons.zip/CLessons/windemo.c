#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>


int main()
{
  HANDLE li,ha;
  li=LoadLibrary("Winmm.dll");
  //
  int WINAPI (*midiOutOpen)(HANDLE*h,UINT,DWORD_PTR,DWORD_PTR,DWORD);
  midiOutOpen=GetProcAddress(li,"midiOutOpen");
  //
  int WINAPI (*midiOutClose)(HANDLE);
  midiOutClose=GetProcAddress(li,"midiOutClose");
  //
  int WINAPI (*midiOutShortMsg)(HMIDIOUT,DWORD);
  midiOutShortMsg=GetProcAddress(li,"midiOutShortMsg");
  //
  //FARPROC CALLBACK
  HANDLE        hmo;
  int           er;
  long          ch;
  long long     qu1,qu2,fr;
  //
  QueryPerformanceCounter( (LARGE_INTEGER*) &qu1);
  QueryPerformanceFrequency((LARGE_INTEGER*) &fr);
  fr/=1000; // for milliseconds
  //
  er=midiOutOpen(&hmo,0,0,0,0);
  midiOutShortMsg(hmo,0x000EC2); // instrument assign ch
  midiOutShortMsg(hmo,0x503791); // v n (n on)  ch
  Sleep(250);
  midiOutShortMsg(hmo,0x503781); // v n (n off) ch
  midiOutShortMsg(hmo,0x503191); // v n (n on)  ch
  Sleep(3500);
  midiOutShortMsg(hmo,0x503081); // v n (n off) ch
  //
  //MessageBox(0,"Hello","Greeting",0);
  //
  //scanf("%c",&ch);
  //
  QueryPerformanceCounter((LARGE_INTEGER*) &qu2);
  long long ti=(qu2-qu1)/fr;
  //printf("%i %i",ha,frd);
  midiOutClose(hmo);
  //
  FreeLibrary(li);
};
