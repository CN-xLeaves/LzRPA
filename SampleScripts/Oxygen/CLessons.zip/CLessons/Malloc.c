
  // FUNCTION POINTER

  #include <stdio.h>
  #include <stdlib.h>

  int foo(int i,int j)
  {
    char *s=(char*) malloc(6);
    char *t=(char*) malloc(3);
    printf ("Result %i %i\n",s,t);
    free(s);
    free(t);
  }

  int (*pfoo)(int i,int j);


  int main()
  {
    pfoo=&foo;
    return pfoo(1,2);
  }
