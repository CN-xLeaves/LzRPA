#include <stdlib.h>
#include <stdio.h>


typedef struct _RGB
{
 char red,green,blue;
} tRGB, *pRGB;

typedef unsigned long tGRAY,*pGRAY;

int main()
{
 int width=640, height=480;
 int e=width*height;
 pRGB  ColorImage = malloc(e*sizeof(tRGB));
 pGRAY GrayImage  = malloc(e*sizeof(tGRAY));
 //...
 int  i;
 pRGB  color = ColorImage;
 pGRAY gray  = GrayImage;
 //
 for (i=0;i<e;i++)
 {
  //RGB to grayscale as (0.299 * R + 0.587 * G + 0.114 * B)
  *gray=(0.299*color->red)+
        (0.587*color->green)+
        (0.114*color->blue);
  color++;
  gray++;
 }
 //...
 free(ColorImage);
 free(GrayImage);
}