// gcc -masm=intel asmtest.c
//
// http://stackoverflow.com/questions/199966/how-do-you-use-gcc-to-generate-assembly-code-in-intel-syntax
// http://www.ibiblio.org/gferg/ldp/GCC-Inline-Assembly-HOWTO.html
// http://gcc.gnu.org/onlinedocs/gcc/Extended-Asm.html

#include <stdint.h>
#include <stdio.h>
#include <windows.h>

int main(int argc, char *argv[])
{
  int64_t a=0;
  int64_t b=101;
  int64_t c=102;
  // a = b + c
  asm
  (
    "sub rsp,64;"
    "mov rcx,0;"
    "mov rdx,0;"
    "mov r8,0;"
    "mov r9,1;"
    "call MessageBoxA;"
    "add rsp,64;"
//
    "mov rax, %1;"
    "add rax, %2;"
    "mov %0, rax;"
    "here:;"
//  "lea rax,here;"
//  "mov %0, rax;"
    : "=m" (a)          // output
    : "m" (b), "m" (c)  // operands "m" from memory : "r" load to register first
    // : "rax","rcx"    // clobbered registers
  );
  printf("sizeof a = %d\n", sizeof(a));
  printf("a = %d\n", a);
  printf("b = %d\n", b);
  printf("c = %d\n", c);
//MessageBox(0,"Hello","C",0);
  return 0;
};
