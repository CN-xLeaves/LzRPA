
  #include <stdio.h>

  int main()
  {
    // int a;
    printf ("Hello World!\n");
    return 0;
  };
