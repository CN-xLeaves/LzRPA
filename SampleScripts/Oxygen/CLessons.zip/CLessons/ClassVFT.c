
  #include <stdlib.h>
  #include <stdio.h>
  #define function
  #define gosub
  #define dim
  #define as
  #define then
  #define sub   void
  #define begin {
  #define end   }
  #define endif }
  #define and   &&
  #define or    ||
  #define class typedef struct
  #define methods
  #define dyn(A,B,C) A B=malloc((C)*sizeof(*B))


  class VectorClassStruct
  begin
    void*vft;
    float x,y,z;
  end *VectorClass;
  typedef struct VectorClassTableStruct
  begin
    function float (*VectorAssign)(VectorClass v, float x,float y,float z);
    function float (*VectorScale) (VectorClass v, float s);
    function float (*VectorFill)  (VectorClass v, int n, int m,...);
  end VectorClassTable;
  methods
  function float VectorAssign(VectorClass v, float x,float y,float z)
  begin
    v[0].x=x;
    v[0].y=y;
    v[0].z=z;
  end;
  function float VectorScale(VectorClass v, float s)
  begin
    v[0].x*=s;
    v[0].y*=s;
    v[0].z*=s;
  end;
  function float VectorFill(VectorClass v, int n, int m,...)
  begin
    int *w=&m;
    int i;
    for (i=0;i<n;i++)
    begin
      v->x=*w; w++;
      v->y=*w; w++;
      v->z=*w; w++;
      v++;
    end;
  end;

  function int main()
  begin
    //
    //build function table
    //
    VectorClassTable t;
    t.VectorAssign=&VectorAssign;
    t.VectorScale=&VectorScale;
    t.VectorFill=&VectorFill;
    //
    //create vector object and assign table
    //
    dyn(VectorClass,v,100);
    v->vft=&t;
    //
    //get function table from object
    //
    VectorClassTable*vFun=v->vft;
    vFun->VectorAssign(&v[10],1.0,2.0,3.0);
    printf("%f,%f,%f\n", v[10].x, v[10].y, v[10].z);
    vFun->VectorFill(v,2,10,20,30,40,50,60);
    printf("%f,%f,%f\n", v[1].x, v[1].y, v[1].z);
    free(v);
  end;
