
  #include <stdlib.h>
  #include <stdio.h>

  #define function
  #define method
  #define gosub
  #define dim
  #define as
  #define to
  #define limit
  #define step
  #define then
  #define sub   void
  #define begin {
  #define end   }
  #define endif }
  #define and   &&
  #define or    ||
  #define class typedef struct
  #define types typedef struct
  #define methods
  #define member ->
  #define addressof &
  #define has =
  #define incr ++
  #define decr --
  #define next ++
  #define prior --
  #define byref *
  #define ref   void*
  #define references = &
  #define NewSpace  malloc
  #define FreeSpace free

  #define create(A,B,C) A B=malloc((C)*sizeof(*B))
  #define copy(A,B,C) CopyInts((int*)A,(int*)B,C);

  /*

  ENTITIES
  ========

  Using Vector as a generic model for OOP

  VectorType
  VectorArray
  VectorClass
  VectorClassTable
  VectorMethods
  VectorObject

  NewVector
  FreeVector

  */

  sub CopyInts(int*d,int*s,int count)
  begin
    count /= sizeof(int); //itr beware packed types
    int i;
    for (i=0; limit i<count; step incr i)
    begin
      *d=*s;
      next d;
      next s;
    end;
  end;


  types VectorStruct
  begin
    float x,y,z;
  end
  VectorType,*VectorArray;


  class VectorClassStruct
  begin
    ref         vft;
    int         count;
    VectorArray v;
  end
  *VectorObject;


  types VectorClassTableStruct
  begin
    method void  (byref Redim)  (VectorObject this,int n);
    method float (byref Assign) (VectorObject this, int i, float x,float y,float z);
    method float (byref Scale)  (VectorObject this, int i, float s);
  end
  VectorClassTable,*VectorMethods;


  methods

  method void VectorRedim(VectorObject this, int n)
  begin
    create(VectorArray,va,n);
    copy(to va, this member v, this member count*sizeof(VectorType));
    free(this member v);
    this member v = va;
    this member count = n;
  end;

  method float VectorAssign(VectorObject this, int i, float x,float y,float z)
  begin
    if (this member count <= i) then VectorRedim(this, i+16);
    VectorArray w references this member v[i];
    w member x = x;
    w member y = y;
    w member z = z;
  end;

  method float VectorScale(VectorObject this, int i, float s)
  begin
    if (this member count <= i) then VectorRedim(this, i+16);
    VectorArray w references this member v[i];
    w member x *= s;
    w member y *= s;
    w member z *= s;
  end;

  function VectorMethods VectorClassTableBuild()
  begin
    static VectorClassTable t;
    VectorMethods vm references t;
    vm member Redim  references method VectorRedim;
    vm member Assign references method VectorAssign;
    vm member Scale  references method VectorScale;
    return vm;
  end

  function VectorObject NewVector()
  begin
    static VectorMethods vm;
    if (vm==0) then vm = VectorClassTableBuild();
    create(VectorObject,this,1);
    this member vft = vm;
    this member count = 16;
    this member v has NewSpace(16*sizeof(VectorType));
    return this;
  end

  sub FreeVector(VectorObject this)
  begin
    FreeSpace(this member v);
    FreeSpace(this);
  end


  function int main()
  begin
    VectorObject vo = NewVector();
    VectorMethods vm=vo member vft;
    vm->Assign(vo, 20, 1.0, 2.0, 3.0);
    vm->Scale(vo, 20, 4.0);
    printf("%i\n",vo member count);
    int i=20;
    printf("%f,%f,%f\n", vo member v[i].x, vo member v[i].y, vo member v[i].z);
    FreeVector(vo);
  end;
