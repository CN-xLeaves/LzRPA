#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
//#include <windows.h>


int q13()
{
  float a;
  printf("Enter float number\n");
  scanf("%f",&a);
  a*=.5;
  printf("Number/2=%f",a);
}

int q14()
{
  char c[8]=" ";
  float a;
  while (a !='n')
  {
    printf("Enter float number\n");
    scanf("%f",&a);
    a*=2;
    printf("Number doubled=%f\n",a);
    printf ("Do another y/n\n");
    scanf("%s",&c);
    if (c[0]=='n') break;
  }
}

float square(float n);

void bang()
{
  printf("BANG!");
}

int MidiNotes[30];

int q21()
{
  int i;
  char a[]="abcdefghijklmnopqrstuvwxyz";
  for (i=0;i<26;i++)
  {
    printf("%c\n",a[i]);
  }
}

int q22()
{
 //start
 char s[64];
 float a,b;
 //start loop
 while (1)
 {
   //1st input from user
   printf ("\nEnter first number ");
   scanf ("%f",&a);
   // 2nd number from user
   printf ("\nEnter second number ");
   scanf ("%f",&b);
   // ask user + or -
   printf ("\nPlus or minus? ");
   scanf ("%s",&s[0]);
   //read response
   //if +
   if (s[0]=='+')
   {
     //print sum
     printf("%f",a+b);
   }
   else if (s[0]=='-')
   {
     //print 1st minus second
     printf("%f",a-b);
   }
   else
   {
     //if response neither + or -
     printf("\nInvalid symbol: Try again\n");
     continue;
   }
   //exit loop
   break;
 //end loop
 }
 //stop
 //
}

int year;
#define num 0xD5
//binary d5 11010101

float pounds=0.0;




int Qxxx()
{
 char let='Q';
 //int data[32]={1,2,3,4};
 //printf("%i\n",data[0]);
 printf("Hello\tWorld!\n");
 printf("%c\n",let);
 printf("%15.4f\n",1.23456);
 float val;
 //scanf("%f",&val);
 printf("%15.4f\n",val);
 //0..511 9 bits
 float x=1.0,y=1.0;
 y=5.0*pow(6.0,(x-2.0)/3.0);
 int time=0;
 if (time==0) {printf("Lift off!\n");}
 float weight=49.0;
 if(weight<50.0){printf("Light\n");}else{printf("Heavy\n");}
 int day=3;
 switch (day)
 {
   case 1 : printf("Monday\n"); break;
   case 2 : printf("Tuesday\n"); break;
   case 3 : printf("Wednesday\n"); break;
   case 4 : printf("Thursday\n"); break;
   case 5 : printf("Friday\n"); break;
 }
  
}

int q9()
{
  //start
  float a,b;
  while (1)
  {
    printf("Enter a number: ");
    scanf("%f",&a);
    printf("Enter another number: ");
    scanf("%f",&b);
    if (a>b)
    {
      printf("Value of 'a' is greater than value of 'b'\n");
    }
    else if (b>a)
    {
      printf("Value of 'b' is greater than value of 'a'\n");
    }
    else
    {
      printf("Values of 'a' and 'b' are equal\n");
      break;
    }
  }
}


int main()
{
 q9();
}