#include <stdlib.h>
#include <stdio.h>

typedef char **string,*binstring,*StringData;


typedef struct
{
 char PoolQuantum;
 char CharWidth;
 char type;
 char reserved;
 int  ByteLen;
}StringInfo;
//
//The String Characterss come immediately after this structure followed by 2 null bytes

#define StringInfoSize sizeof(StringInfo)
#define PoolQuantumStd 6

int SmallStringMaxSize=(1<<PoolQuantumStd)-StringInfoSize;

//for each thread

char* Allocs(int n,char**pool)
{
 int *i=(int*) *pool;
 char*s;
 StringInfo *p;
 if ((n<=24) && (*i>0))
 {
  s=pool[*i]; //recycled string
  (*i)--;
 }
 else
 {
  s=malloc(n);
  p=(StringInfo*) s;
  if (n<=SmallStringMaxSize)
  {
   p->PoolQuantum=PoolQuantumStd;
  }
  else
  { 
   p->PoolQuantum=0;
  }
 }
 return s;
}

void Frees(char*s,char**pool)
{
 if (s==NULL) return;
 int *i=(int*) *pool;
 if ((*s==PoolQuantumStd) && (*i<255))
 {
  (*i)++;
  pool[*i]=s; //recycle small string
 }
 else
 {
  free(s);
 }
}



//These must be defined for each thread
//
char* PoolList;
//
char* StringAlloc(int n)
{
 return Allocs(n,&PoolList);
}
//
void StringFree(char*s)
{
 Frees(s,&PoolList);
}



void  StringSetInfoSpace(string s,int len,int width,int type)
{
 *s=StringAlloc(len*width+StringInfoSize+2);
 StringInfo *p=(StringInfo*) *s;
 p->CharWidth=width;
 p->type=0;
 p->ByteLen=len*width;
 *s+=StringInfoSize;
}

char* StringListExtract(string s)
{
 char*t=*s; //return direct StringData 
 *s=0;      //nullify entry in memlist
 return t;
}

void StringPoolCreate(char**list)
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 *i=0;
}

void StringPoolFree(char**list)
{
 if (*list==0) return;
 int *ii=(int*) *list;
 int i=*ii;
 while (i>0)
 {
  free(list[i]);
  i--;
 }
 free(*list);
}


void StringListCreate(char**list)
//as array of char* byref
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 *i=0;
}

void StringListFree(char**list)
{
 if (*list==0) return;
 int*ii=(int*) *list;
 int i=*ii;
 while (i>0)
 {
  if (list[i]) StringFree(list[i]-StringInfoSize);
  i--;
 }
 free(*list);
}

void StringCreate(string*s, char**list)
{
 int*i=(int*) *list;
 (*i)++;
 *s=(char**) *list+*i*sizeof(char*);
 **s=NULL;
}

void StringDestroy(string *s)
{
 if (**s !=NULL) StringFree(**s-StringInfoSize);
}

void StringCopyBytes(char*dest,char*src,int c)
{
 while(1)
 {
  if (c<=0) break;
  *dest=*src;
  c--;
  dest++;
  src++;
 }
 *dest=0; //null terminators
 dest++;
 *dest=0;
}

void StringCopyInto(char*dest,char*src,int*i)
{
 int j=0;
 while(1)
 {
  dest[*i]=src[j];
  if (src[j]==0) break;
  (*i)++;
  j++;
 }
 dest[*i+1]=0; // extra null terminator
}

void StringCopy0(char*dest,char*src)
{
 int i=0;
 while(1)
 {
  dest[i]=src[i];
  if (src[i]==0) break;
  i++;
 }
 dest[i+1]=0; // extra null terminator
}

int ByteCount(char*c)
{
 int i=0;
 while(1)
 {
   if (c[i]==0) break;
   i++;
 }
 return i;
}

int StringLen(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen / p[-1].CharWidth;
}

int StringByteLen(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen;
}

void StringAllocate(string s, int len, int width)
{
 StringFree(*s); //destroy previous string
 StringSetInfoSpace(s,len,width,0);
}

void StringAssignChars(string s, char*c)
{
 int len=ByteCount(c);
 StringFree(*s); //destroy previous string
 StringSetInfoSpace(s,len,1,0);
 StringCopyBytes(*s,c,len);
}

void StringPrint(string t)
{
 printf("%s", *t );
}


void StringJoin(string t,...)
{
 string *ps;
 ps=&t;
 int i,j,len; 
 i=1;
 len=0;
 while(1)
 {
  if (ps[i]==0) break; //end of string params
  len+=StringByteLen(ps[i]);
  i++; //next string
 }
 StringAllocate(ps[0],len,1);
 i=1;
 j=0;
 while(1)
 {
  if (ps[i]==0) break; //end of string params
  StringCopyInto(*(ps[0]),*(ps[i]),&j);
  i++; //next string
 }
}


void Ltrim(string s)
{
 char*t=*s;
 char*b=t;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  if (t>=e) break;
  if (*t>32) break;
  t++;
 }
 i=i-(int)(t-b);
 char*u;
 StringSetInfoSpace(&u,i,1,0);
 StringCopyBytes(u,t,i);
 StringFree(*s);
 *s=u;
}


void Rtrim(string s)
{
 char*t=*s;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  e--;
  if (e<t) break;
  if (*e>32) break;
 }
 i=1+(int)(e-t);
 char*u;
 StringSetInfoSpace(&u,i,1,0);
 StringCopyBytes(u,t,i);
 StringFree(*s);
 *s=u;
}


/*
TESTS
*/


int main()
{
 StringPoolCreate(&PoolList);
 char* LocalList;
 string r,s,t,u;
 StringListCreate(&LocalList);
 StringCreate(&r,&LocalList);
 StringCreate(&s,&LocalList);
 StringCreate(&t,&LocalList);
 StringCreate(&u,&LocalList);
 StringAssignChars(s,"Hello     ");
 Rtrim(s);
 StringAssignChars(t,"    World!");
 Ltrim(t);
 StringJoin(r,s,t,NULL);
 StringPrint(r);
 printf("\n%i\n",StringLen(r));
 //
 char*h=StringListExtract(r);
 StringListFree(&LocalList); //garbage collection of all local strings
 printf("%s\n",h);
 StringFree(h-sizeof(StringInfo));
 StringPoolFree(&PoolList);
}


