
//gcc CharPrint.c


#include <stdio.h>


void CharPrint(char* t, ...)
{
 char**pt=&t;
 int i=0;
 while (1)
 {
  if (pt[i]==0) return;
  printf("%s", pt[i] );
  i++;
 }
}

int main()
{
 char space[]=" ";
 char comma[]=",";
 char pling[]="!";
 char cr   []="\n";
 CharPrint("Hello",space,"World",comma,space,"Hello",space,"Sky",pling,cr,NULL);
 //Hello World, Hello Sky!
}