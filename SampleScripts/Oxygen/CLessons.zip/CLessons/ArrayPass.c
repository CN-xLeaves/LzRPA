#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>

int f1(float *v)
{
  //return v[0];
}

int main()
{
  float v[100];
  f1(&v[3]);
   
}