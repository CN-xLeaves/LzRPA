#include <stdlib.h>
#include <stdio.h>

typedef char **string,*binstring,*StringData;

//string contents:

typedef struct
{
 char PoolQuantum;
 char CharWidth;
 char type;
 char reserved;
 int  ByteLen;
}StringInfo;
/*
  The String Characters come immediately after this structure followed by 2 null bytes.
  A String points to an element in a list of char pointer elements.
  Each of these pointer elements adresses the char content of the string (char base+String InfoSize).
  When all the strings on the list are out of scope, all the char* are deleted.
*/

#define StringInfoSize sizeof(StringInfo)
#define PoolQuantumStd 6

int SmallStringMaxSize=(1<<PoolQuantumStd)-StringInfoSize; 


/*
The String Pool allows small strings to be recycled when out of scope. (strings within the quantum size)
*/


void StringPoolCreate(char**list)
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 i[0]=1;
 i[1]=0;
}

void StringPoolFree(char**list)
{
 EachChainUnit:
 if (*list==0) return;
 int *ii=(int*) *list;
 int i=*ii;
 char**c=(char**) (*list+i*sizeof(char*));
 while (i>1)
 {
  free(*c);
  c--;
  i--;
 }
 char**cc=(char**) *list;
 char*ch=cc[1];
 free(*list); //done this unit
 *list=ch;
 goto EachChainUnit;
}

char* Allocs(int n,char**list) //pool 
{
 int *i=(int*) *list;
 char*s;
 StringInfo *p;
 if (*i<=1)
 {
  char**cc=(char**) *list;
  char*ch=cc[1];
  if (ch!=0) //another previous chain unit
  {
   free(*list); //done this unit
   *list=ch;
   i=(int*) *list;
  }
 }
 if ((n<=24) && (*i>1))
 {
  s=list[*i]; //recycled string
  (*i)--;
 }
 else
 {
  s=malloc(n);
  p=(StringInfo*) s;
  if (n<=SmallStringMaxSize)
  {
   p->PoolQuantum=PoolQuantumStd;
  }
  else
  { 
   p->PoolQuantum=0;
  }
 }
 return s;
}

void Frees(char*s,char**list) //pool
{
 if (s==NULL) return;
 int *i=(int*) *list;
 if (*i>=255)
 {
  char*ch=*list;
  StringPoolCreate(list); //create new chain unit
  char**cc=(char**) *list;
  cc[1]=ch; // make link to previous chain unit
  i=(int*) *list;
 }
 if (*s==PoolQuantumStd)
 {
  (*i)++;
  list[*i]=s; //recycle small string
 }
 else
 {
  free(s);
 }
}



//These must be defined for each thread
//=====================================
//
char* PoolList;
//
char* StringAlloc(int n)
{
 return Allocs(n,&PoolList);
 //return (char*) malloc(n);
}
//
void StringFree(char*s)
{
 Frees(s,&PoolList);
 //free(s);
}



void StringListCreate(char**list)
//as array of char* byref
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 i[0]=1;
 i[1]=0;
}

void StringListFree(char**list)
{
 EachChainUnit:
 if (*list==0) return;
 int*ii=(int*) *list;
 int i=*ii;
 char**c=(char**) (*list+i*sizeof(int*));
 char*d;
 while (i>1)
 {
  if (*c)
  {
   d=*c-StringInfoSize;
   StringFree(d);
  }
  c--;
  i--;
 }
 char**cc=(char**) *list;
 char*ch=cc[1];
 free(*list); //done this unit
 *list=ch;
 goto EachChainUnit;
}

void StringCreate(char**list, ... ) // params: string*
{
 string**ps=(string**) &list;
 string*s;
 int j=0;
 int*i=(int*) *list;
 while (1)
 {
  j++;
  s=ps[j];
  if (s==NULL) break; //end of param list
  (*i)++;
  if (*i>=255) //New Chain unit
  {
   char*ch=*list;
   StringListCreate(list); //create new unit
   char**cc=(char**) *list;
   cc[1]=ch; //make link to previous unit
   i=(int*) *list;
  }
  *s=(char**) (*list+*i*sizeof(char*));
  **s=(char*) 0;
 }
}

void StringEmpty(string s)
{
 if (*s!=NULL)
 {
  char*p=(*s-StringInfoSize);
  StringFree(p);
 }
}

void StringTransferAttributes(string r,string s)
{
 StringInfo *ri=(StringInfo*) *r;
 StringInfo *si=(StringInfo*) *s;
 ri[-1].CharWidth= si[-1].CharWidth;
 ri[-1].type     = si[-1].type;
}

void  StringSetSpace(string s,int len)
{
 *s=StringAlloc(len+StringInfoSize+2);
 StringInfo *p=(StringInfo*) *s;
 p->ByteLen=len;
 (*s)+=StringInfoSize;
}

void  StringSetInfoSpace(string s,int len,int width,int type)
{
 StringSetSpace(s,len);
 StringInfo *p=(StringInfo*) *s;
 p[-1].CharWidth= width;
 p[-1].type     = type;
 p[-1].ByteLen=len*width;
}

char* StringListExtract(string s)
{
 char*t=*s; //return direct StringData 
 *s=0;      //nullify entry in memlist
 return t;
}


void CopyBytes(char*dest,char*src,int c)
{
 while(1)
 {
  if (c<=0) break;
  *dest=*src;
  c--;
  dest++;
  src++;
 }
}

void CopyBytes00(char*dest,char*src,int c)
{
 CopyBytes(dest,src,c);
 *(dest+c)=0; //null terminators
 *(dest+c+1)=0;
}

void StringCopyInto(char*dest,char*src,int*i)
{
 int j=0;
 while(1)
 {
  dest[*i]=src[j];
  if (src[j]==0) break;
  (*i)++;
  j++;
 }
 dest[*i+1]=0; // extra null terminator
}

void StringCopy0(char*dest,char*src)
{
 int i=0;
 while(1)
 {
  dest[i]=src[i];
  if (src[i]==0) break;
  i++;
 }
 dest[i+1]=0; // extra null terminator
}

int ByteCount(char*c)
{
 int i=0;
 while(1)
 {
   if (c[i]==0) break;
   i++;
 }
 return i;
}

int Len(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen / p[-1].CharWidth;
}

int StringByteLen(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen;
}

void StringAssignChars(string b, ...) // string and char* pairs
{
 int len;
 string*ps=&b;
 string s;
 char* c;
 int i=0;
 while(1)
 {
  if (ps[i]==NULL) return;
  s=ps[i];
  c=(char*) ps[i+1];
  len=ByteCount(c);
  StringEmpty(s); //destroy previous string contents
  StringSetInfoSpace(s,len,1,0);
  CopyBytes00(*s,c,len);
  i+=2;
 }
}

#define Q 1

string StringJoinStrings(string t,...)
{
 string *ps,ss,rs;
 ps=&t;
 int i,j,len; 
 i=1;
 len=0;
 rs=ps[0];
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of string params
  
  len+=StringByteLen(ss);
  i++; //next string
 }
 StringEmpty(t); //destroy previous string
 StringSetInfoSpace(t,len,1,0);
 i=1;
 j=0;
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of string params
  StringCopyInto(*rs,*ss,&j);
  i++; //next string
 }
 return t;
}


string StringJoinChars(string t,...) // other params are char*
{
 char **ps,*ss;
 string rs;
 ps=(char**) &t;
 int i,j,len; 
 i=1;
 len=0;
 rs=(string) ps[0];
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of char* params
  
  len+=ByteCount(ss);
  i++; //next char*
 }
 StringEmpty(t); //destroy previous string
 StringSetInfoSpace(t,len,1,0);
 i=1;
 j=0;
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of char* params
  StringCopyInto(*rs,ss,&j);
  i++; //next string
 }
 return t;
}


int StringLimitsAdjust(string s,int*idx,int*cou)
{
 (*idx)--;
 StringInfo*p=(StringInfo*) (*s-StringInfoSize);
 int w=p->CharWidth;
 if (w>1)
 {
  (*idx)*=w;
  (*cou)*=w;
 }
 int le=StringByteLen(s);
 if (*idx<0) *idx=le+*idx+w;
 int i=*idx+*cou;
 if (i>le) (*cou)-=(i-le);
 if (*cou<0) (*cou)=0;
 return *cou;
}

char Asc(string s, int idx)
{
 int cou=1;
 StringLimitsAdjust(s,&idx,&cou);
 if (cou<1) return 0;
 char *p=*s;
 return p[idx];
}

short Unic(string s, int idx)
{
 int cou=1;
 StringLimitsAdjust(s,&idx,&cou);
 StringInfo*p=(StringInfo*) (*s-StringInfoSize);
 if (cou<1) return 0;
 int w=p->CharWidth;
 if (w=1)
 {
  return 0xff & *((*s)+idx);
 }
 return 0xff & *((short*) (*s)+idx);
}

string Mid(string r, string s, int idx, int cou)
{
 StringLimitsAdjust(s,&idx,&cou);
 char*u;
 StringSetSpace(&u,cou);
 if (*r==0) // temp string requires char* and stringinfo
 {
  StringSetSpace(r,0);
  StringTransferAttributes(r,s);
 }
 StringTransferAttributes(&u,r);
 CopyBytes00(u,(*s)+idx,cou);
 StringEmpty(r);
 *r=u;
 return r;
}

string Left(string r, string s, int cou)
{
 return Mid(r,s,1,cou);
}

string Right(string r, string s, int cou)
{
 return Mid(r,s,-cou,cou);
}

string Ltrim(string r,string s)
{
 char*t=*s;
 char*b=t;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  if (t>=e) break;
  if (*t>32) break;
  t++;
 }
 int d=(int)(t-b);
 i-=d;
 Mid(r,s,d+1,i);
 return r;
}


string Rtrim(string r,string s)
{
 char*t=*s;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  e--;
  if (e<t) break;
  if (*e>32) break;
 }
 i=1+(int)(e-t);
 Mid(r,s,1,i);
 return r;
}

char* StringCreateChar(int width, int type, int ch)
{
 char*u;
 int lc=width*ch;
 u=StringAlloc(lc+StringInfoSize+2);
 StringInfo*p=(StringInfo*) u;
 p->CharWidth=width;
 p->type=type;
 p->ByteLen=lc;
 u+=StringInfoSize;
 return u;
}

string StringCopy(string r, string s)
{
 if (*r != *s)
 {
  char*u=0;
  int len=StringByteLen(s);
  StringSetSpace(&u,len);
  StringTransferAttributes(&u,s);
  CopyBytes(u,*s,len);
  StringEmpty(r);
  *r=u;
 }
 return r;
}

string Lcase(string r,string s)
{
 StringCopy(r,s);
 StringInfo*p=(StringInfo*)*r;
 int wc=p[-1].CharWidth;
 char*cc=*r;
 char c;
 while(1)
 {
  c=*cc;
  if (c==0) break;
  if ((c>=0x41) && (c<=0x5a)) (*cc)+=0x20;
  cc+=wc;
 }
 return r;
}

string Ucase(string r,string s)
{
 StringCopy(r,s);
 StringInfo*p=(StringInfo*)*r;
 int wc=p[-1].CharWidth;
 char*cc=*r;
 char c;
 while(1)
 {
  c=*cc;
  if (c==0) break;
  if ((c>=0x61) && (c<=0x7a)) (*cc)-=0x20;
  cc+=wc;
 }
 return r;
}

void StringResizeBuf(string b, int lb, int lc)
{
 if (lc<lb) lb=lc; //perform buffer truncation
 char *u=StringCreateChar(1,0,lc);
 CopyBytes(u,*b,lb);
 StringEmpty(b);
 *b=u;
}

void StringAppendBuf(string b,int *i,string w)
{
 int lw=StringByteLen(w);
 int lb=StringByteLen(b);
 if (lw+*i>=lb)
 {
  StringResizeBuf(b,lb,0x1000+lb+lw*2);
 }
 CopyBytes(*b,*w+*i,lw);
 (*i)+=lw;
}

void StringPrint(string t, ...)
{
 string*pt=&t;
 int i=0;
 while (1)
 {
   if (pt[i]==0) return;
   printf("%s", *pt[i] );
   i++;
 }
}

void CharPrint(char* t, ...)
{
 char**pt=&t;
 int i=0;
 while (1)
 {
  if (pt[i]==0) return;
  printf("%s", pt[i] );
  i++;
 }
}



/*
TESTS
*/


int main()
{
 char* LocalList;
 string r,s,t; //local strings
 string u1,u2; //temp strings
 //
 StringPoolCreate(&PoolList); //for each thread using strings
 StringListCreate(&LocalList);//for each procedure using strings
 //
 StringCreate(&LocalList,&r,&s,&t,&u1,&u2,NULL);
 StringAssignChars(r," ",s,"Hello  ", t,"  World!", NULL);
 StringJoinChars(r,*Rtrim(u1,s),"<->",*Ltrim(u2,t),NULL);
 Ucase(t,Mid(t,Right(s,t,5),2,10));
 CharPrint("r=",*r," t=",*t," s=",*s,"\n",NULL); //can take several char*
 //
 StringListFree(&LocalList); //garbage collection of all local strings
 StringPoolFree(&PoolList);
}


