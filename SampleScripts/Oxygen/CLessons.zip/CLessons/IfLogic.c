
  #include <stdio.h>

  int main()
  {
    int a=0x80000000;
    if (a)
    {
      printf ("Hello World!\n");
    }
    else
    {
      printf ("GoodBye!\n");
    }
    return 0;
  };
