
   #include <stdio.h>
   #include <string.h>
   #include <math.h>


  int fileio ()
  {

   char filename[]="t.txt";
   FILE *fileptr;
   fileptr=fopen(filename,"w");
   if (fileptr==NULL)
   {
     printf("Error opening t1.c\n");
   }
   else
   {
     printf("Opened t1.c\n");
     int i=0;
     for (i=60 ; i<=72 ; i++)
     {
      fprintf(fileptr,"%i\n",i);
     };
     fclose(fileptr);
     //
     //now read it
     //
     int chars;
     char buf [10000];
     fileptr=fopen(filename,"r");
     fread(&buf,1023,chars,fileptr);
     printf("%s",buf);
     fclose(fileptr);
  };
  return 0;
  }



int main(void)
{
  fileio();
}



