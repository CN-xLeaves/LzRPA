// http://www.ibiblio.org/gferg/ldp/GCC-Inline-Assembly-HOWTO.html
// http://gcc.gnu.org/onlinedocs/gcc/Extended-Asm.html
//
//       asm ( assembler template 
//           : output operands                  /* optional */
//           : input operands                   /* optional */
//           : list of clobbered registers      /* optional */
//           );
/*
CONSTRAINTS
+---+--------------------+
| r |    Register(s)     |
+---+--------------------+
| a |   %eax, %ax, %al   |
| b |   %ebx, %bx, %bl   |
| c |   %ecx, %cx, %cl   |
| d |   %edx, %dx, %dl   |
| S |   %esi, %si        |
| D |   %edi, %di        |
+---+--------------------+

Following constraints are x86 specific.

"r" : Register operand constraint, look table given above.
"q" : Registers a, b, c or d.
"I" : Constant in range 0 to 31 (for 32-bit shifts).
"J" : Constant in range 0 to 63 (for 64-bit shifts).
"K" : 0xff.
"L" : 0xffff.
"M" : 0, 1, 2, or 3 (shifts for lea instruction).
"N" : Constant in range 0 to 255 (for out instruction).
"f" : Floating point register
"t" : First (top of stack) floating point register
"u" : Second floating point register
"A" : Specifies the `a� or `d� registers. This is primarily useful for 64-bit integer values intended to be returned with the `d� register holding the most significant bits and the `a� register holding the least significant bits.
*/

/*
compiling with assembler intel notation (instead of the default Bell)
gcc -masm=intel myprog.c

*/

#include <stdio.h>

int main()
{
  int i,j=42;
  asm
  (
  "mov eax,%1;"
  "mov %0,eax;"
  : "=r" (i)
  : "r"  (j)
  : "eax","ecx"
  );
  printf ("%i",i);
  return i;

}