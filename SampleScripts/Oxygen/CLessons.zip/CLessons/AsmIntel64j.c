// gcc -masm=intel asmtest.c

#include <stdint.h>
#include <stdio.h>

typedef int64_t INT;

INT f(INT a, INT b, INT c, INT d)
{
  printf("ia = %d\n", a);
  printf("ib = %d\n", b);
  printf("ic = %d\n", c);
  printf("id = %d\n", d);
  return 42;
}

int main(int argc, char *argv[])
{
  INT d[4]={10,20,30,40};
  INT aa;
  INT*pd=d;
  // calling function with double-float parameters
  asm
  (
    "mov rax,%1;"
    : "=r" (aa)
    : "m"  (pd)  // operands "m" from memory : "r" load to register first
  );
  asm
  (
    "mov r9, [rax+24];"
    "mov r8, [rax+16];"
    "mov rdx,[rax+8 ];"
    "mov rcx,[rax   ];"
  );
  asm
  (
    "sub rsp,32;"
    "call f;"
    "add rsp,32;"
    "mov %0, rax;"
    : "=r" (aa)
    : "m"  (pd)  // operands "m" from memory : "r" load to register first
  );
  printf("ok   %d\n",aa);
  return 0;
};
