#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>


typedef struct {
  int a;
  int b;
}typ;

//typ t;

int main()
{
   printf("%i\n",1);
}