//#include <stdlib.h>
#include <stdio.h>

int f()
{
  return 20;
};


int main()
{
  printf("%i\n",f());
  int f(int v)
  {
    return v*3;
  };
  printf("%i\n",f(10));
}


