
  #include <stdlib.h>
  #include <stdio.h>
  #define function
  #define gosub
  #define dim
  #define as
  #define then
  #define sub   void
  #define begin {
  #define end   }
  #define endif }
  #define and   &&
  #define or    ||
  #define class typedef struct
  #define methods
  #define dyn(A,B,C) A B=malloc((C)*sizeof(B))

  class VectorClassStruct
  begin
    float x,y,z;
  end *VectorClass ;
  methods
  function float VectorAssign(VectorClass v, float x,float y,float z)
  begin
    v[0].x=x;
    v[0].y=y;
    v[0].z=z;
  end;
  function float VectorScale(VectorClass v, float s)
  begin
    v[0].x*=s;
    v[0].y*=s;
    v[0].z*=s;
  end;
  function float VectorFill(VectorClass v, int n, int m,...)
  begin
    int *w=&m;
    int i;
    for (i=0;i<n;i++)
    begin
      v->x=*w; w++;
      v->y=*w; w++;
      v->z=*w; w++;
      v++;
    end;
  end;


  function int main()
  begin
    //dim as VectorClass v=malloc(100*sizeof(*v));
    dyn(VectorClass,v,100);
    printf ("%i\n",sizeof(*v));
    VectorAssign(&v[10],1.0,2.0,3.0);
    VectorScale(&v[10],4.0);
    printf("%f,%f,%f\n", v[10].x, v[10].y, v[10].z);
    VectorFill(v,2,10,20,30,40,50,60);
    printf("%f,%f,%f\n", v[1].x, v[1].y, v[1].z);
    free(v);
  end;
