
  #include <stdio.h>

  int main()
  {
    int a;

    asm("mygosub:\n");
    a=4;
    asm("ret\n");
    
    asm("call mygosub\n");
    printf("%i",a);
    return 0;

  }
