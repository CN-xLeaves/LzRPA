#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>


int fa()
{
int a;
goto la;
la:;
}

int fb()
{
int a;
goto la;
la:;
}

int main()
{
   fa();
   fb();
}