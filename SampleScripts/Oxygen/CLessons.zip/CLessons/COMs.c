/*
FUNCTION IUnknown_Release (BYVAL pthis AS DWORD PTR) AS DWORD
    LOCAL DWRESULT AS DWORD
    IF pthis THEN
       CALL DWORD @@pthis[2] USING IUnknown_Release(pthis) TO DWRESULT
       FUNCTION = DWRESULT
    END IF
END FUNCTION

header Unknwn.h
*/

#include <stdio.h>

//ad hoc definitions for these types:

typedef int HRESULT,ULONG;

typedef struct tGUID {
 unsigned long  A[2];
 unsigned short B[2];
 unsigned char  C[8];
} GUID, *REFIID;

typedef struct _fUnknown
{
 HRESULT (*QueryInterface)(void* pvObject, REFIID riid, void **ppvObject);
 ULONG (*AddRef)(void* pvObject);
 ULONG (*Release)(void* pvObject);
} fUnknown,*pfUnk;


ULONG ReleaseObject(pfUnk*pthis)
{
 if (pthis)
 {
  return pthis[0]->Release(pthis);
 }
}

//test with dummy functions

HRESULT QueryInterface(void* pvObject,REFIID riid,void **ppvObject){printf("QueryInterface");};
ULONG   AddRef(void* pvObject){printf("Addref");};
ULONG   Release(void* pvObject){printf("Release");};



int ReleaseObjectA(void*pthis)
{
 if (pthis)                  // valid COM object pointer
 {
  void**ppfunc=pthis;        //address object body
  void**pfunc=*ppfunc;       //address function table
  ULONG (*Release)(void*pthis);   //declare function
  Release=pfunc[2];          //assign function address by index
  return Release(pthis);     //make call with object
 }
}



int main()
{
 //build function table
 void** t[3]={(void*) &QueryInterface,(void*) &AddRef, (void*) &Release};
 //construct minimal COM object body
 pfUnk ob=(pfUnk) t;
 //create a COM object pointer
 pfUnk *pob=&ob;
 //invoke a COM method
 //ReleaseObject(pob);
 ReleaseObjectA(pob);
 return 0;
}
