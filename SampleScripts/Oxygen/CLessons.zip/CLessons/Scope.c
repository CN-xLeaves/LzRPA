#include <stdlib.h>
#include <stdio.h>


int main()
{
  int a=2;
  {
    int a=3;
    printf("%i\n",a); //result 3
  };
  printf("%i\n",a); //result 2
}




