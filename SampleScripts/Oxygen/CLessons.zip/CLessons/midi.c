#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>
#include <mmsystem.h>

HMIDIOUT initm()
{
HMIDIOUT hMidi;
MMRESULT  er;
//er=midiOutOpen(&hMidi, 0, 0, 0, CALLBACK_NULL); // 0=synth a 2=soft synth
er=midiOutShortMsg(hMidi, 0xff) ;        //reset
//er=midiOutShortMsg(hMidi, 0x79B0);       //reset all controllers
//er=midiOutShortMsg(hMidi, 0xC0+0x0E00);  //program assign
return hMidi;
};

int main()
{
};