// gcc -masm=intel asmtest.c

#include <stdint.h>
#include <stdio.h>

typedef int64_t INT;

void f(INT a, INT b, INT c, INT d)
{
  printf("ia = %d\n", a);
  printf("ib = %d\n", b);
  printf("ic = %d\n", c);
  printf("id = %d\n", d);
}

int main(int argc, char *argv[])
{
  INT d[4]={10,20,30,40};
  INT*pd=d;
  INT aa;
  // calling function with double-float parameters
  asm
  (
    "sub rsp,32;"
    "mov rax,%1;"
    "mov r9, [rax+24];"
    "mov r8, [rax+16];"
    "mov rdx,[rax+8 ];"
    "mov rcx,[rax   ];"
    "call f;"
    "add rsp,32;"
    : "=m" (aa)
    : "m"  (pd)  // operands "m" from memory : "r" load to register first
  );
  printf("ok\n");
  return 0;
};
