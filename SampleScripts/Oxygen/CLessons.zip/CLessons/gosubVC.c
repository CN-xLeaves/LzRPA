
  #include <stdio.h>

  int main()
  {
    int a;
    void mygosub()
    {
     a=42;
    }
    mygosub();
    printf("%i",a); // 42
  }
