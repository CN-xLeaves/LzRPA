
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char * bstring;


const int empty[4]={0,0,0,0};


bstring bstringbuf(int n)
{
  if (n==0) return (char*) &empty+4;
  int*t=malloc(n+8);
  *t=n;
  *(t+n-4)=0;
  return (char*) t+4;
}

bstring bstringnuls(int n)
{
  if (n==0) return (char*) &empty+4;
  int m=(n+12)>>2;
  int*t=calloc(m,sizeof(long));
  *t=n;
  return (char*) t+4;
}

void bstringfree(bstring*s)
{
  if (s==NULL) return;
  if (*s==NULL) return;
  free(*s-sizeof(long));
  *s=(bstring) &empty+4; 
}

long bstringlen(bstring s)
{
  if (s==NULL) return 0;
  return *((long*)(s-sizeof(long)));
}

void bstringcat(bstring *s,bstring t)
{
  if (t==NULL) return;
  int ls,lt,le;
  ls=bstringlen(*s);
  lt=bstringlen(t);
  if (lt==0) return;
  le=ls+lt;
  if (le>0)
  {
    bstring b=bstringnuls(le);
    strcpy(b,*s);
    strcpy(b+ls,t);
    bstringfree(s);
    *s=b;
  }
}

void bstringcatl(bstring *s,char*t)
{
  if (t==NULL) return;
  int ls,lt,le;
  ls=bstringlen(*s);
  lt=strlen(t);
  if (lt==0) return;
  le=ls+lt;
  if (le>0)
  {
    bstring b=bstringnuls(le);
    if (*s != NULL) strcpy(b,*s);
    strcpy(b+ls,t);
    bstringfree(s);
    *s=b;
  }
}

void bstringsetlen(bstring *s,int n)
{
  if (n==0) return;
  int ls,lt,le;
  ls=bstringlen(*s);
  lt=n-ls;
  if (lt==0) return;
  le=ls+lt;
  if (le>0)
  {
    bstring b=bstringnuls(le);
    if (*s != NULL)
    {
      strncpy(b,*s,le);
    }
    bstringfree(s);
    *s=b;
  }
}

void bstringleft(bstring*t,bstring s,int n)
{
  if (n<=0) n=0;
  int le=bstringlen(s);
  if (le>n) le=n;
  bstring b=bstringnuls(le);
  if (s != NULL) strncpy(b,s,le);
  bstringfree(t);
  *t=b;
}

void bstringmid(bstring*t,bstring s,int p,int n)
{
  p--;
  int le=bstringlen(s);
  if (n<0) n=0;
  if (p<0) p=le+p+1;   //offset from right
  if (n>=le-p) n=le-p; //limit with offset
  if (n<0) n=0;
  bstring b=bstringnuls(n);
  if (s != NULL) strncpy(b,s+p,n);
  bstringfree(t);
  *t=b;
}

void bstringmidp(bstring*t,bstring s,int p)
{
  p--;
  int lt=bstringlen(*t);
  int ls=bstringlen(s);
  if (p<0) p=lt+p+1;   //offset from right
  if (ls>=lt-p) ls=lt-p; //limit with offset
  if (ls<=0) return;
  if (s != NULL) strncpy(*t+p,s,ls);
}

void bstringmidpl(bstring*t,char* s,int p)
{
  p--;
  int lt=bstringlen(*t);
  int ls=strlen(s);
  if (p<0) p=lt+p+1;   //offset from right
  if (ls>=lt-p) ls=lt-p; //limit with offset
  if (ls<=0) return;
  if (s != NULL) strncpy(*t+p,s,ls);
}


int main()
{
  //TESTS
  //
  bstring       p=NULL,q=NULL;
  bstringcatl   (&p,"Hello ");
  bstringcatl   (&q,"World ");
  bstringcat    (&p,q);
  bstringcatl   (&p," ok");
  bstringsetlen (&p,15);
  bstringmid    (&p,p,-9,11);
  bstringmidpl  (&p,"X",2);
  printf        ("%s\n",p);
  printf        ("%i\n",bstringlen(p));
  bstringfree   (&p);
}
