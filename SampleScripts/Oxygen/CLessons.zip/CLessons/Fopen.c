  // http://www.cplusplus.com/reference/clibrary/cstdio/fopen/

  /* fopen example */
  #include <stdio.h>
  int main ()
  {
  FILE * pFile;
  pFile = fopen ("myfile.txt","w");
  if (pFile!=NULL)
  {
    fputs ("fopen example",pFile);
    fclose (pFile);
  }
  return 0;
 }
