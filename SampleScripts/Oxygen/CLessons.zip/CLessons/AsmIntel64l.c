// gcc -masm=intel asmtest.c

#include <stdint.h>
#include <stdio.h>

typedef int64_t INT;

INT fi(INT a, INT b, INT c, INT d, INT e, INT f, INT g, INT h)
{
  printf("ia = %d\n", a);
  printf("ib = %d\n", b);
  printf("ic = %d\n", c);
  printf("id = %d\n", d);
  printf("id = %d\n", e);
  printf("id = %d\n", f);
  printf("id = %d\n", g);
  printf("id = %d\n", h);
  return 42;
}

int main(int argc, char *argv[])
{
  INT d[18]={10,20,30,40,50,60,70,80};
  INT ia;
  INT*pd=d;
  INT pn=8;
  // INT bb[100];
  // calling function with double-float parameters
  asm
  (
    //
    "mov rax,%1;"
    "mov r9,%2;"
    "sub rsp,64;"
    "mov rcx,rsp;"
    "mov r8,r9;"
    "dec r8;"
    "shl r8,3;"
    "sub r9,4;"
    "jle nmovpar;"
    //
    "rmovpar:"
    "mov rdx,[rax+r8]; mov [rcx+r8],rdx;"
    "sub r8,8; dec r9; jg rmovpar;"
    "nmovpar:"
    //
    "mov r9, [rax+24];"
    "mov r8, [rax+16];"
    "mov rdx,[rax+8 ];"
    "mov rcx,[rax   ];"
    "call fi;"
    "mov %0,rax;"
    "add rsp,64;"
    : "=r" (ia)
    : "m"  (pd), "m" (pn) // operands "m" from memory : "r" load to register first
    //
  );
  printf("ok   %d\n",ia);
  printf("ok   %d\n",pn);
  return 0;
};
