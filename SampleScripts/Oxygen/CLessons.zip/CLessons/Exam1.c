
   #include <stdio.h>
   #include <string.h>
   #include <math.h>


void stuff(void)
{
   char buf[1000];
   char c;
   printf("Enter a string of characters\n");
   scanf("%s",&buf[0]);
   int i=0;
   int count=0;
   int len=strlen(buf);
   for (i=0 ; i<len ; i++)
   {
    c=buf[i];
    if (c=='a' || c=='e' || c=='i' ||  c=='o' || c=='u')
    {
     count++;
    }
   }
  printf("Vowel count = %i\n",count);
};



  typedef struct {
   float x;
   float y;
  } point;


  point o={0,0};

  point square[4];

  point midpoint(point p1, point p2)
  {
   point mid;
   mid.x=(p1.x+p2.x)/2;
   mid.y=(p1.y+p2.y)/2;
   return mid;
  }

  int fileio ()
  {

   char filename[]="t.txt";
   FILE *fileptr;
   fileptr=fopen(filename,"w");
   if (fileptr==NULL)
   {
     printf("Error opening t1.c\n");
   }
   else
   {
     printf("Opened t1.c\n");
     int i=0;
     for (i=60 ; i<=72 ; i++)
     {
      fprintf(fileptr,"%i\n",i);
     };
     fclose(fileptr);
     //
     //now read it
     //
     int chars;
     char buf [10000];
     fileptr=fopen(filename,"r");
     fread(&buf,1023,chars,fileptr);
     printf("%s",buf);
     fclose(fileptr);
  };
  return 0;
  }

  #define bitmask 1

  int pointers(void)
  {
   int *num_ptr;
   int num[100];
   num_ptr=&num[0];
   *num_ptr=0;
   num_ptr += sizeof(int);

  }

  float parallels(void)
  {
   float r[100];
   int i=0;
   while (1)
   {
    printf("\nEnter Resistor value or 0: ");
    scanf("%f",&r[i]);
    if (r[i]==0)
    {
      break;
    }
    if (i>=100)
    {
     break;
    }
    i++;
   }
   int e=i-1;
   float val=0.0;
   for (i=0 ; i<=e ; i++)
   {
    val+=1/r[i];
   }
   return 1/val;
  }
 //printf("\nParallel value= %9.2f\n",parallels());


  int ShowHWaves(void)
  {
   int i=0,j=0,e=90,n=0;
   float v=0.0;
   for (i=0 ; i<=e ; i++)
   {
    v =sin(i/3.0);
    v+=sin(i/1.0)*.5;
    n=v*15+30;
    printf("%3.2f ",v+2);
    for (j=1 ; j<=n ; j++)
    {
     printf("X");
    }
    printf("\n");
   }


  }
  int ShowVWaves(void)
  {
   char c[79][60]; // x y
   //
   //clear with spaces
   //
   int i=0,j=0,e=79,n=0;
   float v=0.0;
   for (i=0 ; i<e ; i++)
   {
     for (j=0 ; j<60 ; j++)
     {
       c[i][j]=' '; //spaces
     }
   }
   //
   //plot
   //
   for (i=0 ; i<e ; i++)
   {
     v =sin(i/3.0);
     v+=sin(i/1.0);
     n=v*15+30;
     n-=1;
     if (n<0) {n=0;}; //limit
     if (n>60) {n=60;}; //limit
     for (j=0 ; j<n ; j++)
     {
       c[i][j]='X'; //plot char into array
     }
   }
   //
   //print
   /*
   for (i=0 ; i<e ; i++)
   {
    for (j=0 ; j<60 ; j++)
    {
     printf("%c",c[i][j]);
    }
    printf("\n");
   }
   */
   for (j=0 ; j<60 ; j++)
   {
    for (i=0 ; i<e ; i++)
    {
     printf("%c",c[i][59-j]); //upside down
    }
    printf("\n");
   }
  } // end showVwaves


  int ShowVWaves2(void)
  {
   char c[79][60]; // x y
   //
   //clear with spaces
   //
   int i=0,j=0,e=79,n=0;
   float v=0.0;
   for (i=0 ; i<e ; i++)
   {
     for (j=0 ; j<60 ; j++)
     {
       c[i][j]=' '; //spaces
     }
   }
   //
   //plot
   //
   for (i=0 ; i<e ; i++)
   {
     v =sin(i/3.0);
     //v+=sin(i/1.0);
     n=v*15+30;
     n-=1;
     if (n<0) {n=0;}; //limit
     if (n>60) {n=60;}; //limit
     for (j=0 ; j<n ; j++)
     {
       c[i][j]='X'; //plot char into array
     }
   }
   //
   //print
   /*
   for (i=0 ; i<e ; i++)
   {
    for (j=0 ; j<60 ; j++)
    {
     printf("%c",c[i][j]);
    }
    printf("\n");
   }
   */
   for (j=0 ; j<60 ; j++)
   {
    for (i=0 ; i<e ; i++)
    {
     if (j<30)
     {
       printf("%c",c[i][59-j]); //upside down
     }
     else
     {
       printf(" ",c[i][59-j]); //upside down
     }    
    }
    printf("\n");
   }
  } // end showVwaves





int main(void)
{
 //signals
 char signalA[]="1111000011110000";
 char signalB[]="0011110000111100";
 char signalC[]="1001000100010001";
 int a,b,c,ab,bc,nbc,x;
 int i,ok,le;
 le=strlen(signalA);
 for (i=0 ; i<le ; i++ )
 {
    //inputs
    //
    a=signalA[i] & 1;
    b=signalB[i] & 1;
    c=signalC[i] & 1;
    //
    // logic gates
    //
    if ((a==1) && (b==1))    {ab=1;}  else {ab=0;}  // AND
    if ((b==1) || (b==1))    {bc=1;}  else {bc=0;}  // OR
    if (bc==1)               {nbc=0;} else {nbc=1;} // NOT              // NOT
    if ((ab==1) ^ (nbc==1))  {x=1;}   else {x=0;}   // XOR
    
    if (x==1){printf("1");} else {printf ("0");}
 }
 printf("\n");
}



