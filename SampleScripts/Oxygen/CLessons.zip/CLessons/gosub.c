
  #include <stdio.h>

  int main()
  {
    int a;
    void mygosub()
    {
     a=4;
    }
    mygosub();
    printf("%i",a);
  }
