// gcc -masm=intel asmtest.c
//

#include <stdint.h>
#include <stdio.h>

double f(double a, double b, double c, double d)
{
  printf("da = %Lf\n", a);
  printf("db = %Lf\n", b);
  printf("dc = %Lf\n", c);
  printf("dd = %Lf\n", d);
  return 42.75;
}

int main(int argc, char *argv[])
{
  double d[4]={1.25,2.25,3.25,4.25};
  double*pd=d;
  double rd;
  // calling function with double-float parameters
  asm
  (
    "sub rsp,32;"
    "mov rax,%1;"
    "movups xmm0,[rax   ];"
    "movups xmm1,[rax+ 8];"
    "movups xmm2,[rax+16];"
    "movups xmm3,[rax+24];"
    "call f;"
    "movups [esp],xmm0;"
    "mov rax,[esp];"
    "add rsp,32;"
    "mov %0,rax;"
    : "=m" (rd)
    : "m"  (pd)  // operands "m" from memory : "r" load to register first
  );
  printf("return = %Lf\n", rd);
  printf("ok\n");
  return 0;
};
