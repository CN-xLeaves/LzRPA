
/*

HOW TO:

http://cygwin.com/cygwin-ug-net/dll.html

'this uses CDECL calling convention

gcc -c DLLm.c
gcc -shared -o DLLm.dll DLLm.o

...testing prog

gcc -o myprog myprog.c -L./ -lDLLm

full spec compiling:

gcc -shared -o cyg${module}.dll \
    -Wl,--out-implib=lib${module}.dll.a \
    -Wl,--export-all-symbols \
    -Wl,--enable-auto-import \
    -Wl,--whole-archive ${old_libs} \
    -Wl,--no-whole-archive ${dependency_libs}

*/

int STRPTR(int n) // pas the string by reference
{
  return n;
}

int VARPTR(int n) // pass the int/float/any variable by reference
{
  return n;
}


int PEEK8(char* n)
{
  return *n; //& 0xff; // bit mask to support clean integer return
}


void POKE8(char* n, char v)
{
  *n=v;
}


int PEEK32(int* n)
{
  return *n; 
}


void POKE32(int* n, int v)
{
  *n=v;
}

float PEEKFLOAT(float * n)
{
  return *n; 
}


void POKEFLOAT(float * n, float v)
{
  *n=v; 
}


double PEEKDOUBLE(double * n)
{
  return *n; 
}


void POKEDOUBLE(double * n, double v)
{
  *n=v; 
}


