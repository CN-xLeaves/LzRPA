
  // ARRAY OVERLAY

  #include <stdio.h>
  #include <stdlib.h>


  int main()
  {
    int* m=(int*) malloc(1024); //heapspace
    float*va=(float*) m;        //map float array to m
    va[1]=10.0;                 //test
    printf("%f\n",va[1]);
    free(m);
  }
