
  //Ellipsis

  //#include <stdlib.h>
  #include <stdio.h>

  int f(int n,...)
  {
    int*p=&n;
    int a=p[n]+p[n-1];
    printf ("Result %i \n",a); // result 14
  }


  int main()
  {
    int a=4;
    return f(a,2,4,6,8);
  }
