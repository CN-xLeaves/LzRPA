/*
FUNCTION IUnknown_Release (BYVAL pthis AS DWORD PTR) AS DWORD
    LOCAL DWRESULT AS DWORD
    IF pthis THEN
       CALL DWORD @@pthis[2] USING IUnknown_Release(pthis) TO DWRESULT
       FUNCTION = DWRESULT
    END IF
END FUNCTION

header Unknwn.h
*/

#include <stdio.h>

//ad hoc definitions for these types:

typedef int HRESULT,ULONG;

typedef struct tGUID {
 unsigned long  A[2];
 unsigned short B[2];
 unsigned char  C[8];
} GUID, *REFIID;


HRESULT (*QueryInterface)(
  void* pvObject,
  REFIID riid,
  void **ppvObject
);

ULONG (*AddRef)(void* pvObject);

ULONG (*Release)(void* pvObject);


int ReleaseObject(void*pvObject)
{
 if (pvObject) // valid COM object pointer
 {
  void**ppfunc=pvObject;     //address object body
  void**pfunc=*ppfunc;       //address function table
  Release=pfunc[2];          //index for func table member
  return Release(pvObject);  //make call with object
 }
}

int main()
{
 return 0;
}
