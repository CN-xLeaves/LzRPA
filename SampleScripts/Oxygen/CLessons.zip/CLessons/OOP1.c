#include <stdlib.h>
#include <stdio.h>


//VIRTUAL TABLE

typedef struct 
{
  int (*m1)(void*this);
  int (*m2)(void*this);
  int c;
} vfoo;

//OBJECT

typedef struct 
{
  vfoo *vtp;
  int  a;
} cfoo;

//METHODS

int m1(void*this)
{
  cfoo*c=this;
  c->a=4;
  c->vtp->m2(this);
  return 1;
};

int m2(void*this)
{
  cfoo*c=this;
  printf("ok");
  return 2;
};

//CREATE

int main()
{
  vfoo tfoo={&m1,&m2,1}; //virtual part. (once for all objects)
  cfoo foo={&tfoo,0};    //object part. (each object)
  foo.vtp->m1(&foo);
  printf("%i",foo.a);
}


