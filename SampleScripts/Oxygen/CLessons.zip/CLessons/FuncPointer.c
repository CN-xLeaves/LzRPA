
  // FUNCTION POINTER

  #include <stdio.h>

  int foo(int i,int j)
  {
    printf ("Result %i \n",i+j);
  }

  int (*pfoo)(int i,int j);


  int main()
  {
    pfoo=&foo;
    return pfoo(1,2);
  }
