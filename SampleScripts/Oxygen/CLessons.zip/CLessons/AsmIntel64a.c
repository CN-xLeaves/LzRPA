// gcc -masm=intel asmtest.c

#include <stdint.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
  int64_t a=0;
  int64_t b=101;
  int64_t c=102;
  // a = b + c
  // asm requires string literals
  asm
  (
    "mov rax, %1;"
    "add rax, %2;"
    "mov %0, rax;"
    : "=m" (a)          // output
    : "m" (b), "m" (c)  // operands "m" from memory : "r" load to register first
  );
  printf("sizeof a = %d\n", sizeof(a));
  printf("a = %d\n", a);
  printf("b = %d\n", b);
  printf("c = %d\n", c);
  return 0;
};
