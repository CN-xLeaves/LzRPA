
  /* bit testing and setting using macros */

  #include <stdio.h>

  #define Bit(a,n,i) if ((n & 1<<i)==0) a=0; else a=1
  #define BitSet(n,i) n |=(1<<i)
  #define BitReset(n,i) n &=(~(1<<i))
  #define BitToggle(n,i) n ^=(1<<i)

  int main ()
  {
  //tests
  int m[]={0x5,0xd,0x15};
  char c[100]="@EF";
  int b=1;
  int a;
  Bit(a,m[1],b);
  printf ("%x\n", a);
  Bit(a,c[1],b);
  printf ("%x\n", a);
  BitToggle(c[1],b);
  printf ("%x\n", c[1]);
  BitToggle(c[1],b);
  printf ("%x\n", c[1]);
  return 0;
  }

