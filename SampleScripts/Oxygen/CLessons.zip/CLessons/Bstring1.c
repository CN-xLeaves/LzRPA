
//=================
//Bstring Functions 
//=================


  #include <stdio.h>
  #include <stdlib.h>

  typedef char * bstring;
  #define NEW_STRINGS        -1
  #define FREE_STRINGS       -2
  #define FREE_PRIOR_STRINGS -3
  


//--------------------------
  bstring StringAgent(int n)
//==========================
  {
  static int b[4000];
  static int a, bb, c;
  int *p;
  char*q;
//itr too many strings?
  //
  if (n<0)
  {
    if (n==-1)
    {
      b[bb]=-1; //set fence
      bb++;
      return (bstring) 0;
    }
    //
    if (bb<=0)
    {
      return (bstring) 0; //empty list
    }
    //
    if (n<-2)
    {
      bb--; // do not delete most recent string
      c=b[bb];
      if (c==-1)
      {
        return (bstring) 0; //exit if is was a fence
      }
    }
    //
    if (bb>0)
    {
      while (bb>0)
      {
        bb--;
        a=b[bb];
        if (a==-1)
        {
          exit; //stop at fence
        }
        free( (char*) a); //free strings
      }
    }
    if (n<-2)
    {
     b[bb++]=c; //place most recent string back in list
    }
    return (bstring) 0;
  }
  //
  //n>=0 create string of length n
  //
  a=n+6;
  p = (int*) malloc (a);
  *p = n;
  b[bb]=(int) p;
  p++;
  q=(bstring) p;
  q+=n;
  *q=(char) 0; //null terminator
  q++;
  *q=(char) 0; //extra null terminator
  bb++;
  return (bstring) p;
  }


//------------------------
  bstring NewString(int n)
//========================
  {
  return StringAgent(n);
  }



//------------------
  int Len(bstring s)
//==================
  {
  int * p=(int*) s;
  p--;
  return *p;
  }



//----------------------------------------
  void FillString(bstring s, int n, int c)
//========================================
  {
  int i;
  for (i=0 ; i<n ; i++)
  {
  *s = (char) c;
  s++;
  }
  }



//-------------------------
  bstring NullString(int n)
//=========================
  {
  bstring s=StringAgent(n);
  FillString(s,n,0);
  return s;
  }




//-------------------------
  int FreeString(bstring s)
//=========================
  {
  if (s==0) return 0;
  free(s-4);
  return 0;
  }




//------------------------------------
  bstring Mid(bstring s, int i, int l)
//====================================
  {
  bstring t;
  bstring u;
  int le;
  int les=Len(s);
  int j;
  if (i<0)
  {
    i=les+1+i; //offset from the right
  }
  le=l+i-1;
  if (le>les)
  {
   l=les-i+1;
  }
  if (l<0) l=0;
  t=NullString(l);
  if (i>les) return t;
  u=t;
  s+=i-1;
  for (j=0 ; j<=l ; j++) // includes boundary null
  {
    *u++ = *s++;
  }
  return t;
  }



//------------------------------
  bstring Left(bstring s, int i)
//==============================
  {
  return Mid(s,1,i);
  }



//-------------------------------
  bstring Right(bstring s, int i)
//===============================
  {
  return Mid(s,-i,Len(s));
  }




//------------------
  bstring Chr(int i)
//==================
  {
  bstring s=NewString(1);
  *s=(char) i;
  s[1]=(char) 0;
  return s;
  
  }




//--------------------------
  short Asc(bstring s,int i)
//==========================
  {
  long le=Len(s);
  if (i<0)
  {
   i=le+i+1; //offset from the right
  }
  if (i<1) return 0;
  if (i>le) return 0;
  i--;
  return (short) s[i] & 0xff;
  
  }   



//---------------------------------------------
  void PatchString(bstring s, int j, bstring u)
//=============================================
  {   
    int i,e=Len(u);
    s+=j;
    for (i=0; i<e; i++)
    {
     *s++=*u++;
    }
  }



//-------------------------
  bstring Concat(int n,...)
//=========================
  {
    bstring *b=(bstring*) &n; //setup pointer to bstring parameters
    bstring s,t;
    int i,c=0;
    for (i=1; i<=n; i++)
    {
      c+=Len(b[i]);
    }
    s=NewString(c);
    c=0;
    //
    for (i=1; i<=n; i++)
    {
      t=b[i];
      PatchString(s,c,t);
      c+=Len(t);
    }
    return s;
  }



//-----------
  int main ()
//===========
  {
  int i,n;
  bstring s,t;

  printf ("How long do you want the string? ");
  scanf ("%d", &i);

  StringAgent(NEW_STRINGS);

  s=NullString(i);
  t=NullString(i);
  if (s==NULL) exit (1);

  for (n=0; n<i; n++)
    s[n]=rand()%26+'a';
  s[i]='\0';

  t=Mid(s,-2,64);
  printf ("Random string: %s, %s, %i, %s \n",s, t, Asc(t,2), Chr(65) );

  t=Concat(2,s,s);
  printf ("Composite string: %s\n",t);

  StringAgent(FREE_STRINGS);


  return 0;
  };
