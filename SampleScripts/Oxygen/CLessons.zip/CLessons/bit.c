
  /* bit testing and setting example */

  #include <stdio.h>

  int Bit(int *n,int i)
  {
   if ((*n & 1<<i)==0) return 0; else return 1;
  }

  void BitSet(int *n,int i)
  {
   *n |= 1<<i;
  }


  void BitReset(int *n,int i)
  {
   int b=~(1<<i);
   *n &=b;
  }

  void BitToggle(int *n,int i)
  {
   int b=1<<i;
   *n ^=b;
  }


  int main ()
  {
  //tests
  int m[]={0x5,0xd,0x15};
  char c[100]="@EF";
  int i=1;
  printf ("%i\n", Bit(&m[i],1));
  BitSet(&m[i],1);
  printf ("%i\n", Bit(&m[i],1));
  BitReset(&m[i],1);
  printf ("%i\n", Bit(&m[i],1));
  BitToggle(&m[i],1);
  BitToggle((int*)&c[i],1);
  printf ("%i\n", Bit(&m[i],1));
  BitToggle(&m[i],1);
  BitToggle((int*)&c[i],1);
  printf ("%i\n", Bit(&m[i],1));
  printf ("%x\n", m[i]);
  printf ("%x\n", c[i]);
  return 0;
  }

