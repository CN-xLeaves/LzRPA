
  #include <stdlib.h>
  #include <stdio.h>
  #define function
  #define gosub
  #define dim
  #define as
  #define then
  #define sub   void
  #define begin {
  #define end   }
  #define endif }
  #define and   &&
  #define or    ||
  #define class typedef struct
  #define methods
  #define dyn(A,B,C) A B=malloc((C)*sizeof(*B))


  class VectorClassStruct
  begin
    void*vft;
    float x,y,z;
  end *VectorObject;
  typedef struct VectorClassTableStruct
  begin
    function float (*Assign) (VectorObject v, float x,float y,float z);
    function float (*Scale)  (VectorObject v, float s);
    function float (*Fill)   (VectorObject v, int n, int m,...);
  end VectorClassTable,*VectorMethods;
  methods
  function float VectorAssign(VectorObject v, float x,float y,float z)
  begin
    v[0].x=x;
    v[0].y=y;
    v[0].z=z;
  end;
  function float VectorScale(VectorObject v, float s)
  begin
    v[0].x*=s;
    v[0].y*=s;
    v[0].z*=s;
  end;
  function float VectorFill(VectorObject v, int n, int m,...)
  begin
    int *w=&m;
    int i;
    for (i=0;i<n;i++)
    begin
      v->x=*w; w++;
      v->y=*w; w++;
      v->z=*w; w++;
      v++;
    end;
  end;
  function VectorMethods VectorClassTableBuild(void)
  begin
    static VectorClassTable st;
    VectorMethods t=&st;
    t->Assign = &VectorAssign;
    t->Scale  = &VectorScale;
    t->Fill   = &VectorFill;
    return t;
  end
  function VectorObject NewVector()
  begin
    static VectorMethods vm=0;
    if (vm==0) then vm = VectorClassTableBuild();
    dyn(VectorObject,v,1);
    v->vft=vm;
    return v;
  end
  sub FreeVector(VectorObject v)
  begin
    free(v);
  end


  function int main()
  begin
    VectorObject v = NewVector();
    VectorMethods vm=v->vft;
    vm->Assign(v,1.0,2.0,3.0);
    printf("%f,%f,%f\n", v->x, v->y, v->z);
    FreeVector(v);
  end;
