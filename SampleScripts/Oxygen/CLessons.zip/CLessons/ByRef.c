#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>


typedef struct
{
  int a,b;
}typ;

void f(typ*v)
{
  printf("%i",v->a);
}

int main()
{
  typ a[4]; //pointer
  void *b;
  int c;
  c=(int) &a[0];
  b=(void*) c;
  a->a=42;
  f(b);    
}