
  #include <stdio.h>

  int main()
  {
    int a=4;
    goto m1;
    a=2;
    m1:    
    printf("%i",a);
    return 0;

  }
