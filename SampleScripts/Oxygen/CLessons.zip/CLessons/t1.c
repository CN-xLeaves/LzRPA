
  #include <stdio.h>

  typedef enum
  {
   aaa=1,bbb=2
  }aa;

  int main()
  {
    int a=bbb;
    printf("%i",a);
    return 0;
  }
