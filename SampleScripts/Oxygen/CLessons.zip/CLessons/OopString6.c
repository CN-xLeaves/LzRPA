#include <stdlib.h>
#include <stdio.h>

typedef char **string,*binstring,*StringData;


typedef struct
{
 char PoolQuantum;
 char CharWidth;
 char type;
 char reserved;
 int  ByteLen;
}StringInfo;
//
//The String Characterss come immediately after this structure followed by 2 null bytes

#define StringInfoSize sizeof(StringInfo)
#define PoolQuantumStd 6

int SmallStringMaxSize=(1<<PoolQuantumStd)-StringInfoSize;

void StringPoolCreate(char**list)
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 i[0]=1;
 i[1]=0;
}

void StringPoolFree(char**list)
{
 EachChainUnit:
 if (*list==0) return;
 int *ii=(int*) *list;
 int i=*ii;
 while (i>1)
 {
  free(list[i]);
  i--;
 }
 char**cc=(char**) *list;
 char*ch=cc[1];
 free(*list); //done this unit
 *list=ch;
 goto EachChainUnit;
}

char* Allocs(int n,char**list) //pool 
{
 int *i=(int*) *list;
 char*s;
 StringInfo *p;
 if (*i<=1)
 {
  char**cc=(char**) *list;
  char*ch=cc[1];
  if (ch!=0) //another previous chain unit
  {
   free(*list); //done this unit
   *list=ch;
   i=(int*) *list;
  }
 }
 if ((n<=24) && (*i>1))
 {
  s=list[*i]; //recycled string
  (*i)--;
 }
 else
 {
  s=malloc(n);
  p=(StringInfo*) s;
  if (n<=SmallStringMaxSize)
  {
   p->PoolQuantum=PoolQuantumStd;
  }
  else
  { 
   p->PoolQuantum=0;
  }
 }
 return s;
}

void Frees(char*s,char**list) //pool
{
 if (s==NULL) return;
 int *i=(int*) *list;
 if (*i>=255)
 {
  char*ch=*list;
  StringPoolCreate(list); //create new chain unit
  char**cc=(char**) *list;
  cc[1]=ch; // make link to previous chain unit
  i=(int*) *list;
 }
 if (*s==PoolQuantumStd)
 {
  (*i)++;
  list[*i]=s; //recycle small string
 }
 else
 {
  free(s);
 }
}



//These must be defined for each thread
//=====================================
//
char* PoolList;
//
char* StringAlloc(int n)
{
 return Allocs(n,&PoolList);
}
//
void StringFree(char*s)
{
 Frees(s,&PoolList);
}


void StringTransferAttributes(string r,string s)
{
 StringInfo *ri=(StringInfo*) *r-StringInfoSize;
 StringInfo *si=(StringInfo*) *s-StringInfoSize;
 ri->CharWidth= si->CharWidth;
 ri->type     = si->type;
}

void  StringSetSpace(string s,int len)
{
 *s=StringAlloc(len+StringInfoSize+2);
 StringInfo *p=(StringInfo*) *s;
 p->ByteLen=len;
 (*s)+=StringInfoSize;
}

void  StringSetInfoSpace(string s,int len,int width,int type)
{
 *s=StringAlloc(len*width+StringInfoSize+2);
 StringInfo *p=(StringInfo*) *s;
 p->CharWidth=width;
 p->type=type;
 p->ByteLen=len*width;
 int a=(int) *s;
 (*s)+=StringInfoSize;
}

char* StringListExtract(string s)
{
 char*t=*s; //return direct StringData 
 *s=0;      //nullify entry in memlist
 return t;
}


void StringListCreate(char**list)
//as array of char* byref
{
 *list=(char*) malloc(256*sizeof(char*));
 int*i=(int*) *list;
 i[0]=1;
 i[1]=0;
}

void StringListFree(char**list)
{
 EachChainUnit:
 if (*list==0) return;
 int*ii=(int*) *list;
 int i=*ii;
 while (i>1)
 {
  if (list[i]) StringFree(list[i]-StringInfoSize);
  i--;
 }
 char**cc=(char**) *list;
 char*ch=cc[1];
 free(*list); //done this unit
 *list=ch;
 goto EachChainUnit;
}

void StringCreate(string*s, char**list)
{
 int*i=(int*) *list;
 (*i)++;
 if (*i>=255) //New Chain unit
 {
  char*ch=*list;
  StringListCreate(list); //create new unit
  char**cc=(char**) *list;
  cc[1]=ch; // make link to previous unit
  i=(int*) *list;
 }
 *s=(char**) *list+*i*sizeof(char*);
 **s=NULL;
}

void StringEmpty(string s)
{
 if (*s !=NULL) StringFree((*s)-StringInfoSize);
}

void StringCopyBytes(char*dest,char*src,int c)
{
 while(1)
 {
  if (c<=0) break;
  *dest=*src;
  c--;
  dest++;
  src++;
 }
 *dest=0; //null terminators
 dest++;
 *dest=0;
}

void StringCopyInto(char*dest,char*src,int*i)
{
 int j=0;
 while(1)
 {
  dest[*i]=src[j];
  if (src[j]==0) break;
  (*i)++;
  j++;
 }
 dest[*i+1]=0; // extra null terminator
}

void StringCopy0(char*dest,char*src)
{
 int i=0;
 while(1)
 {
  dest[i]=src[i];
  if (src[i]==0) break;
  i++;
 }
 dest[i+1]=0; // extra null terminator
}

int ByteCount(char*c)
{
 int i=0;
 while(1)
 {
   if (c[i]==0) break;
   i++;
 }
 return i;
}

int StringLen(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen / p[-1].CharWidth;
}

int StringByteLen(string s)
{
 StringInfo *p=(StringInfo*) *s;
 return p[-1].ByteLen;
}

void StringAllocate(string s, int len, int width)
{
 StringEmpty(s); //destroy previous string
 StringSetInfoSpace(s,len,width,0);
}

void StringAssignChars(string s, char*c)
{
 int len=ByteCount(c);
 StringEmpty(s); //destroy previous string
 StringSetInfoSpace(s,len,1,0);
StringInfo*p=(StringInfo*) (*s-StringInfoSize);

 StringCopyBytes(*s,c,len);
}

void StringPrint(string t)
{
 printf("%s", *t );
}

#define Q 1

void StringJoin(string t,...)
{
 string *ps,ss,rs;
 ps=&t;
 int i,j,len; 
 i=1;
 len=0;
 rs=ps[0];
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of string params
  
  len+=StringByteLen(ss);
  i++; //next string
 }
 StringAllocate(rs,len,1);
 i=1;
 j=0;
 while(1)
 {
  ss=ps[i];
  if (ss==0) break; //end of string params
  StringCopyInto(*rs,*ss,&j);
  i++; //next string
 }
}


void StringLimitsAdjust(string s,int*idx,int*cou)
{
 (*idx)--;
 StringInfo*p=(StringInfo*) (*s-StringInfoSize);
 int w=p->CharWidth;
 if (w>1)
 {
  (*idx)*=w;
  (*cou)*=w;
 }
 int le=StringByteLen(s);
 if (*idx<0) *idx=le+*idx+w;
 int i=*idx+*cou;
 if (i>le) (*cou)-=(i-le);
 if (*cou<0) (*cou)=0;
}

char StringAsc(string s, int idx)
{
 int cou=1;
 StringLimitsAdjust(s,&idx,&cou);
 if (cou<1) ; return 0;
 return *((*s)+idx);
}

short StringUnic(string s, int idx)
{
 int cou=1;
 StringLimitsAdjust(s,&idx,&cou);
 StringInfo*p=(StringInfo*) (*s-StringInfoSize);
 if (cou<1) ; return 0;
 int w=p->CharWidth;
 if (w=1)
 {
  return 0xff & *((*s)+idx);
 }
 return 0xff & *((short*) (*s)+idx);
}

void StringMid(string r, string s, int idx, int cou)
{
 StringLimitsAdjust(s,&idx,&cou);
 char*u;
 StringSetSpace(&u,cou);
 StringTransferAttributes(&u,r);
 StringCopyBytes(u,(*s)+idx,cou);
//printf("%s,%i\n",u,cou);
 StringEmpty(r);
 *r=u;
}

void StringLeft(string r, string s, int cou)
{
 char*u;
 StringSetSpace(&u,cou);
 StringTransferAttributes(&u,r);
 StringCopyBytes(u,(*s),cou);
 StringEmpty(r);
 *r=u;
}

void Ltrim(string r,string s)
{
 char*t=*s;
 char*b=t;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  if (t>=e) break;
  if (*t>32) break;
  t++;
 }
 int d=(int)(t-b);
 i-=d;
 StringMid(r,s,d+1,i);
}


void Rtrim(string r,string s)
{
 char*t=*s;
 int i=StringByteLen(s);
 char*e=t+i;
 while(1)
 {
  e--;
  if (e<t) break;
  if (*e>32) break;
 }
 i=1+(int)(e-t);
 StringMid(r,s,1,i);
}


/*
TESTS
*/


int main()
{
 StringPoolCreate(&PoolList);
 char* LocalList;
 string r,s,t,u;
 StringListCreate(&LocalList);
 StringCreate(&r,&LocalList);
 StringCreate(&s,&LocalList);
 StringCreate(&t,&LocalList);
 StringCreate(&u,&LocalList);
 StringAssignChars(s,"Hello     ");
 Rtrim(s,s);
 StringAssignChars(t,"    World!");
 Ltrim(t,t);
 StringJoin(r,s,t,NULL);
 StringPrint(r);
 printf("\n%i\n",StringLen(r));
 //
 char*h=StringListExtract(r);
 StringListFree(&LocalList); //garbage collection of all local strings
 printf("%s\n",h);
 StringFree(h-StringInfoSize);
 StringPoolFree(&PoolList);
}


