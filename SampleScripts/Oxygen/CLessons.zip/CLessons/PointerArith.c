
  //POINTER ARITHMETIC

  #include <stdio.h>

  int f(int *i,int *j)
  {
    if (*i!=0) printf ("%i\n",*i);
    i--;
    printf ("Result %i, %i \n",i,j);
  }


  int main()
  {
    int a=1,b=0;
    return f(&a,&b);
  }
