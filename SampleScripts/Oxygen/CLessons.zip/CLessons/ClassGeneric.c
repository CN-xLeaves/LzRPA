
  #include "Basic.c"

  /*

  ENTITIES:
  =========

  GenericType
  GenericArray
  GenericClass
  GenericClassTable
  GenericMethods
  GenericObject
  GenericParameters

  PROCEDURES
  ==========
  New
  Free

  METHODS:
  ========
  Get
  Set
  Move
  Action
  Show
  (other Operations...)
  Translate
  Rotate

  */

  #define GenericParametersByVal float x, float y, float z
  #define GenericParametersByRef float *x, float *y, float *z

  types GenericStruct
  begin
    float x,y,z;
  end
  GenericType,*GenericArray;


  class GenericClassStruct
  begin
    ref         vft;
    int         count;
    GenericArray v;
  end
  *GenericObject;


  types GenericClassTableStruct
  begin
    method sub (byref Redim)   (GenericObject this,int n);
    method int (byref Get)     (GenericObject this, int i, GenericParametersByRef);
    method int (byref Set)     (GenericObject this, int i, GenericParametersByVal);
    method int (byref Move)    (GenericObject this, int i, float x, float y, float z);
    method int (byref Action)  (GenericObject this, int i, float s);
    method int (byref Show)    (GenericObject this, int i, float s);
  end
  GenericClassTable,*GenericMethods;


  //methods

  method void GenericRedim(GenericObject this, int n)
  begin
    create(GenericArray,va,n);
    CopyBytes(to va, this member v, this member count*sizeof(GenericType));
    free(this member v);
    this member v = va;
    this member count = n;
  end;

  method int GenericGet(GenericObject this, int i, GenericParametersByRef)
  begin
    if (this member count <= i) then GenericRedim(this, i+16);
    GenericArray w references this member v[i];
    *x = w member x;
    *y = w member y;
    *z = w member z;
  end;

  method int GenericSet(GenericObject this, int i, GenericParametersByVal)
  begin
    if (this member count <= i) then GenericRedim(this, i+16);
    GenericArray w references this member v[i];
    w member x = x;
    w member y = y;
    w member z = z;
  end;

  method int GenericMove(GenericObject this, int i, float x, float y, float z)
  begin
    if (this member count <= i) then GenericRedim(this, i+16);
    GenericArray w references this member v[i];
    w member x += x;
    w member y += y;
    w member z += z;
  end;

  method int GenericAction(GenericObject this, int i, float s)
  begin
    if (this member count <= i) then GenericRedim(this, i+16);
    GenericArray w references this member v[i];
  end;

  method int GenericShow(GenericObject this, int i, float s)
  begin
    if (this member count <= i) then GenericRedim(this, i+16);
    GenericArray w references this member v[i];
    printf("%f,%f,%f\n", w member x, w member y, w member z);
  end;


  function GenericMethods GenericClassTableBuild()
  begin
    static GenericClassTable t;
    GenericMethods vm references t;
    vm member Redim   references method GenericRedim;
    vm member Get     references method GenericGet;
    vm member Set     references method GenericSet;
    vm member Move    references method GenericMove;
    vm member Action  references method GenericAction;
    vm member Show    references method GenericShow;
    return vm;
  end

  function GenericObject NewGeneric()
  begin
    static GenericMethods vm;
    if (vm==0) then vm = GenericClassTableBuild();
    create(GenericObject,this,1);
    this member vft = vm;
    this member count = 16;
    this member v has NewSpace(16*sizeof(GenericType));
    return this;
  end

  sub FreeGeneric(GenericObject this)
  begin
    FreeSpace(this member v);
    FreeSpace(this);
  end


  function int main()
  begin
    GenericObject vo = NewGeneric();
    GenericMethods vm=vo member vft;
    vm->Set(vo, 20, 1.0, 2.0, 3.0);
    vm->Show(vo,20,0);
    vm->Move(vo, 20, 1,1,1);
    vm->Show(vo,20,0);
    FreeGeneric(vo);
  end;
