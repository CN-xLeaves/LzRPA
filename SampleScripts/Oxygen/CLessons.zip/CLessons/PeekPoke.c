
int STRPTR(int n) // pas the string by reference
{
  return n;
}

int VARPTR(int n) // pass the int/float/any variable by reference
{
  return n;
}


char PEEK8(char* n)
{
  return *n;
}


int PEEK32(int* n)
{
  return *n; 
}

void POKE32(int* n, int v)
{
  *n=v;
}

void POKE8(char* n, char v)
{
  *n=v;
}

int main()
{
  int v,w,r;
  r=PEEK32(&v);
  POKE32(&w,r);
  
  char v1,w1,r1;
  r1=PEEK8(&v1);
  POKE8(&w1,r1);
  return 0;
}

