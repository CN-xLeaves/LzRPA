#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <windows.h>


int q6ca()
{
 int i=0;
 int j;
 while (i<=9)
 {
   j=0;
   while (j<=i)
   {
    printf("%i",j);
    j++;
   }
   printf("\n");
   i++;
 }
}

int q6c()
{
 int i,j;
 for (i=0;i<=9;i++)
 {
   for (j=0;j<=i;j++)
   {
    printf("%i",j);
   }
   printf("\n");
 }
}

int statvar()
{
 static int i;
 printf("%i\n",i);
 i=4;
}


int q6a()
{
  //float y;
  //float x=.9999;
  //y=1.0/(3-pow(x,20.0));
  //printf("%f",y);
  //if (y<90){printf("Sub-Bass");}else{}

  float y;
  printf ("Enter a number: ");
  scanf("%f",&y);
  y/=4;
  printf("number/4=%f",y);
}

int loops()
{
  int i,n;
  printf ("Enter number of loops to perform: ");
  scanf("%i",&n);
  for (i=1;i<=n;i++)
  {
    printf("Loop!\n");
  }
}

int vowels()
{
  char n[256];
  printf ("Enter String: ");
  scanf("%s",n);
  int i=0;
  int c=0;
  while (n[i]!='\0')
  {
   switch (n[i])
   {
     case 'a' : c++; break;
     case 'e' : c++; break;
     case 'i' : c++; break;
     case 'o' : c++; break;
     case 'u' : c++; break;
     case 'A' : c++; break;
     case 'E' : c++; break;
     case 'I' : c++; break;
     case 'O' : c++; break;
     case 'U' : c++; break;
   }
break;
   i++;
  }
  printf("Number of vowels: %i ",c);
 
}

int strings()
{
  char s1[100];
  char s2[100]="Hello ";
  char s3[100]="World!";
  //strncat(s2,s3,100);
  //strncpy(s1,s2,5);
  //s1[5]='\0';
  //printf("%s\n",s1);
  //printf("%i\n",strlen(s1));

  //compare s2 with s3
  int a;
  a=strcmp(s2,s3);
  printf("%i\n",a);


  a=strcmp(s2,s3);
  printf("%i\n",a);
  if (a>0)
  {
   printf ("%s greater than %s",s2,s3);
  }
  else if (a<0)
  {
   printf ("%s less than %s",s2,s3);
  }
 
  else // (a==0)
  {
   printf ("%s equals %s",s3,s2);
  }
}


int files()
{
 char s[100];
 FILE * f;
 f=fopen("t.txt","w");
 fprintf(f,"Hello World!\n");
 fclose(f);

 f=fopen("t.txt","r");
 fread(s,1,100,f);
 printf("%s",s);
 fclose(f);
}


int stringfuncs()
{
  int i;
  float f;
  char c;
  char s[100]="Hello";
  //scanf("%d",&i);
  //printf("%d",i);
  //scanf("%f",&f);
  //printf("%f",f);
  //scanf("%c",&c);
  //printf("%c",c);

  //scanf("%s",s);
  gets(s);

  printf("%s\n",s);

  printf("%i\n",strlen(s));

  char t[100];

  strncpy(t,s,strlen(s)+1);

  printf("%s\n",t);

  strcat(t," world!");
  printf("%s\n",t);

  sprintf(t,"Hello %i, %f", strlen(s), atan(1)*4 );
  printf("%s",t);
  
}


int add(int a,int b); //declaration


//....

int add(int a,int b) //complete definition
{
 return a+b;
}


int arrays()
{
 int i[10]= {0,2,4,6,8,10,12,14};
 printf("%i\n",i[2]);
 i[2]+=40;
 printf("%i\n\n",i[2]);
 int j;
 for (j=0;j<8;j++)
 {
   printf("%i\n",i[j]);
 }

}


int main()
{
   printf("%i\n",add(1,2));
}